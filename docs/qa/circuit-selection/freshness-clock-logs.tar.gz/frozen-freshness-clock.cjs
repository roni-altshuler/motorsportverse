beforeAll(() => {
  jest.useFakeTimers({ now: new Date(process.env.FRESHNESS_TEST_CLOCK) });
});
afterAll(() => jest.useRealTimers());
