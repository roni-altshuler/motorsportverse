import { readFileSync } from "node:fs";
import {
  artifactTimestamp,
  compareArtifactTimes,
  qualifyingAssumption,
  weatherAssumption,
} from "/workspace/motorsportverse-circuit-explorer/projects/f1-predictions/website/src/lib/predictionFreshness.ts";
const root = "/workspace/motorsportverse-circuit-explorer/projects/f1-predictions/website/public/data/";
const ranking = JSON.parse(readFileSync(root + "rounds/round_16.json", "utf8"));
const probability = JSON.parse(readFileSync(root + "probabilities/round_16.json", "utf8"));
const contradictory = {
  ...ranking,
  qualifyingDataAvailable: true,
  dataFreshness: { qualifyingSource: "model estimate", weatherSource: "api" },
};
console.log(JSON.stringify({
  ranking: {
    timestamp: artifactTimestamp(ranking.generatedAt),
    qualifying: qualifyingAssumption(ranking),
    weather: weatherAssumption(ranking),
    trioWithFactors: ranking.classification.slice(0, 3).filter((e) => e.keyFactors?.length).length,
    allDriversWithFactors: ranking.classification.filter((e) => e.keyFactors?.length).length,
  },
  probabilityTimestamp: artifactTimestamp(probability.generatedAt),
  rankingVersusProbability: compareArtifactTimes(artifactTimestamp(ranking.generatedAt), artifactTimestamp(probability.generatedAt)),
  reverseTestActual: compareArtifactTimes(artifactTimestamp("2026-09-27T01:06:55Z"), artifactTimestamp(ranking.generatedAt)),
  contradictoryTestActual: { qualifying: qualifyingAssumption(contradictory), weather: weatherAssumption(contradictory) },
}, null, 2));
